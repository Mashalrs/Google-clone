// src/components/Footer.js
import React from 'react';
import './Footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-left">
        <button className="footer-button">Advertising</button>
        <button className="footer-button">Business</button>
        <button className="footer-button">How Search works</button>
      </div>
      <div className="footer-center">
        <button className="footer-button">Carbon neutral since 2007</button>
      </div>
      <div className="footer-right">
        <button className="footer-button">Privacy</button>
        <button className="footer-button">Terms</button>
        <button className="footer-button">Settings</button>
      </div>
    </footer>
  );
};

export default Footer;