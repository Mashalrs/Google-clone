import React, { useState, useRef } from 'react';
import './Search.css';
import googleLogo from '../assets/google-logo.png';
import micIcon from '../assets/mic-icon.png';
import cameraIcon from '../assets/camera-icon.png';

const Search = () => {
  const [luckyText, setLuckyText] = useState("I'm Feeling Lucky");
  const options = ["I'm Feeling Curious", "I'm Feeling Hungry", "I'm Feeling Happy", "I'm Feeling Playful", "I'm Feeling Lucky"];
  const luckyButtonRef = useRef(null);

  const handleLuckyHover = () => {
    const randomOption = options[Math.floor(Math.random() * options.length)];
    setLuckyText(randomOption);
  };

  const handleLuckyLeave = () => {
    setLuckyText("I'm Feeling Lucky");
  };

  return (
    <div className="search-container">
      <img src={googleLogo} alt="Google Logo" className="google-logo" />
      <div className="search">
        <div className="search-input-container">
          <svg className="search-icon" focusable="false" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
            <path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"></path>
          </svg>
          <input type="text" className="search-input" />
          <div className="search-icons">
            <img src={micIcon} alt="Voice Search" className="mic-icon" />
            <img src={cameraIcon} alt="Camera" className="camera-icon" />
          </div>
        </div>
        <div className="search-buttons">
          <button className="search-button">Google Search</button>
          <button 
            ref={luckyButtonRef}
            className="search-button lucky-button"
            onMouseEnter={handleLuckyHover}
            onMouseLeave={handleLuckyLeave}
            data-text={luckyText}
          >
            <span className="lucky-text">I'm Feeling Lucky</span>
          </button>
        </div>
      </div>
      <a href="https://www.google.com" target="_blank" rel="noopener noreferrer" className="google-link">
        Compare with actual Google Search
      </a>
    </div>
  );
};

export default Search;