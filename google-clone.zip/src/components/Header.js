// src/components/Header.js
import React from 'react';
import './Header.css';

const Header = () => {
  return (
    <header className="header">
      <div className="left-links">
        <button className="link-button">About</button>
        <button className="link-button">Store</button>
      </div>
      <div className="right-links">
        <button className="link-button">Gmail</button>
        <button className="link-button">Images</button>
        <div className="icons">
          <button className="grid-icon">⋮⋮⋮</button>
          <button className="profile-icon">M</button>
        </div>
      </div>
    </header>
  );
};

export default Header;